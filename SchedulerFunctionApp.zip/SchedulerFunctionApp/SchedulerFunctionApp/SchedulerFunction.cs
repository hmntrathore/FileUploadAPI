using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

public static class SchedulerFunctionApp
{
    [FunctionName("SchedulerFunction")]
    public static IActionResult Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = null)] HttpRequest req,
        ILogger log)
    {
        log.LogInformation("ScheduleFunction HTTP trigger function processed a request.");

        string startDateString = req.Query["startDate"];
        string schedulingType = req.Query["schedulingType"];
        string endDateString = req.Query["endDate"];
        bool isWorkingDayOnly = false;
        bool.TryParse(req.Query["isWorkingDayOnly"], out isWorkingDayOnly);
        string daysOfWeekString = req.Query["daysOfWeek"];
        List<DayOfWeek> daysOfWeek = new List<DayOfWeek>();

        if (string.IsNullOrEmpty(startDateString) || string.IsNullOrEmpty(schedulingType))
        {
            return new BadRequestObjectResult("Please provide startDate and schedulingType parameters.");
        }

        DateTime startDate;
        if (!DateTime.TryParse(startDateString, out startDate))
        {
            return new BadRequestObjectResult("Invalid startDate format. Please provide a valid DateTime format.");
        }

        DateTime endDate= new DateTime();
        if (!string.IsNullOrEmpty(endDateString) && !DateTime.TryParse(endDateString, out endDate))
        {
            return new BadRequestObjectResult("Invalid endDate format. Please provide a valid DateTime format.");
        }

        DateTime nextRunDateTime = startDate;

        if (isWorkingDayOnly)
        {
            do
            {
                switch (schedulingType.ToLower())
                {
                    case "minutely":
                        int minutesToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = nextRunDateTime.AddMinutes(minutesToAdd);
                        break;
                    case "hourly":
                        int hoursToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = nextRunDateTime.AddHours(hoursToAdd);
                        break;
                    case "daily":
                        int daysToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = nextRunDateTime.AddDays(daysToAdd);
                        break;
                    case "weekly":
                        int weeksToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = GetNextWeeklyRun(nextRunDateTime, weeksToAdd, daysOfWeek);
                        break;
                    case "monthly":
                        int monthsToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = GetNextMonthlyRun(nextRunDateTime, monthsToAdd);
                        break;
                    case "yearly":
                        int yearsToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                        nextRunDateTime = GetNextYearlyRun(nextRunDateTime, yearsToAdd);
                        break;
                }

                if (!string.IsNullOrEmpty(endDateString) && nextRunDateTime > endDate)
                {
                    return new OkObjectResult(endDate);
                }
            } while (!IsWorkingDay(nextRunDateTime));
        }
        else
        {
            switch (schedulingType.ToLower())
            {
                case "minutely":
                    int minutesToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = nextRunDateTime.AddMinutes(minutesToAdd);
                    break;
                case "hourly":
                    int hoursToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = nextRunDateTime.AddHours(hoursToAdd);
                    break;
                case "daily":
                    int daysToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = nextRunDateTime.AddDays(daysToAdd);
                    break;
                case "weekly":
                    int weeksToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = GetNextWeeklyRun(nextRunDateTime, weeksToAdd, daysOfWeek);
                    break;
                case "monthly":
                    int monthsToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = GetNextMonthlyRun(nextRunDateTime, monthsToAdd);
                    break;
                case "yearly":
                    int yearsToAdd = GetNumberToAdd(req.Query["numberToAdd"]);
                    nextRunDateTime = GetNextYearlyRun(nextRunDateTime, yearsToAdd);
                    break;
            }
        }

        if (!string.IsNullOrEmpty(endDateString) && nextRunDateTime > endDate)
        {
            return new OkObjectResult(endDate);
        }

        return new OkObjectResult(nextRunDateTime);
    }

    private static int GetNumberToAdd(string numberToAddString)
    {
        int numberToAdd;
        if (!int.TryParse(numberToAddString, out numberToAdd))
        {
            numberToAdd = 1;
        }
        return numberToAdd;
    }

    private static DateTime GetNextWeeklyRun(DateTime currentDate, int weeksToAdd, List<DayOfWeek> daysOfWeek)
    {
        DateTime nextRunDate = currentDate.AddDays(7 * weeksToAdd);
        while (!daysOfWeek.Contains(nextRunDate.DayOfWeek))
        {
            nextRunDate = nextRunDate.AddDays(1);
        }
        return nextRunDate;
    }

    private static DateTime GetNextMonthlyRun(DateTime currentDate, int monthsToAdd)
    {
        DateTime nextRunDate = currentDate.AddMonths(monthsToAdd);
        return nextRunDate;
    }

    private static DateTime GetNextYearlyRun(DateTime currentDate, int yearsToAdd)
    {
        DateTime nextRunDate = currentDate.AddYears(yearsToAdd);
        return nextRunDate;
    }

    private static bool IsWorkingDay(DateTime date)
    {
        return date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday;
    }
}
