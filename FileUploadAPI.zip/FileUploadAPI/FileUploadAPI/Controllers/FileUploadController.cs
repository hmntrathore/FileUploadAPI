﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FileUploadAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
        private IFileUploader uploader;    
        private readonly ILogger _logger;
      

        public FileUploadController(IConfiguration config, IFileUploader fileUploader)
        {
            
            uploader = fileUploader;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            var a= HttpContext.Connection.RemoteIpAddress;
            
            await uploader.WriteFile(file);
            return Ok();
        }


        [HttpPost("Multiple", Name = "Multiple")]
        [RequestFormLimits(MultipartBodyLengthLimit = 10000000, ValueCountLimit = 2)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UploadFile(IFormFileCollection files)
        {
            if (files == null)
            {
                throw new ArgumentException("please upload the file using files key");
            }

            IFileUploader uploader = new FileUploader();
          
            foreach (var file in files)
            {
                await uploader.WriteFile(file);
            }
            return Ok();


        }

       
    }
}
