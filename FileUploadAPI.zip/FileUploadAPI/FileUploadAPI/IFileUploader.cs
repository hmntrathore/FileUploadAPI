﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace FileUploadAPI
{
    public interface IFileUploader
    {
        public  Task<bool> WriteFile(IFormFile file);
    }
}